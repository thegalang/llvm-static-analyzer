/*
Name: Galangkangin Gotera
Matric number: A0274760Y
Email: galangkangin@u.nus.edu
*/
int main() {
   int a, b, x, y, w, z;

   while(a != b) {
     if (a > b) {
       x = b - a;
       y = a + b;
       z = y + w;
     }
     else {
      x = a + b;
      y = b - a;
      z = y + a;
     } 
  }
}

