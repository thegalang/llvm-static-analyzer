/*
Name: Galangkangin Gotera
Matric number: A0274760Y
Email: galangkangin@u.nus.edu
*/
int main() {
   int a, b, x, y, w, z;

   if (a > b) {
     x = b - a;
     y = a + b;
   }
   else if(b < a){
    x = a + b;
    y = b - a;
   } 
   else {
    w = a + b;
    a = w + b;
    z = b - a;
   }
}

