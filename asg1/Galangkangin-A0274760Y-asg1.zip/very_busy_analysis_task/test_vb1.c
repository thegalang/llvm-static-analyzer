/*
Name: Galangkangin Gotera
Matric number: A0274760Y
Email: galangkangin@u.nus.edu
*/
int main() {
   int a, b, x, y, w, z;


   // b - a and a + b are very busy
   if (a > b) {
     x = b - a;
     y = a + b;
   }
   else if(a < b) {
    x = a + b;
    y = b - a;
   } else {
    w = a + b;
    z = b - a;
    x = b * a;
   }
}

