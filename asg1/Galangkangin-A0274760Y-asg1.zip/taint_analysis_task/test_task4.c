/*
Name: Galangkangin Gotera
Matric number: A0274760Y
Email: galangkangin@u.nus.edu
*/
int main() {
	int i,j, sink, source = 42, N;
	// read source from input
	int a = 0;

	while (a < N) {
		if (a % 2 == 1) i = source;
		else j = i;
		
		a++;
	}

	sink = j;
}
