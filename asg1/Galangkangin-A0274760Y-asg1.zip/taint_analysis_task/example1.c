/*
Name: Galangkangin Gotera
Matric number: A0274760Y
Email: galangkangin@u.nus.edu
*/
int main() {
	int i,j,k,sink, source = 42;
	// read source from user input or it can be
	// initilized with a tainted value. e.g. source = 1234567
	i = source;
	if (j > 1)
		{}
	else
		k = i;
	
	sink = k;
}
