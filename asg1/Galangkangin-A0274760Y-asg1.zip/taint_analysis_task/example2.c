/*
Name: Galangkangin Gotera
Matric number: A0274760Y
Email: galangkangin@u.nus.edu
*/
int main() {
	int i,j,k,sink, source=42;
	// read source from input
	if (i > 1)
		j = source;
	else
		k = j;

	sink = k;
}
